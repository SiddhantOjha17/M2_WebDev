from django.dispatch import receiver
from django.db.models.signals import post_save, post_delete
from .models import Tasks


@receiver(post_save, sender=Tasks)
def autoGenSS(sender, instance, created, **kwargs):
    print('Automatically Fired Signal!!! ----- (after post_save)')
    if created:
        Tasks.objects.create(
            name=instance.name,
            desc=instance.techStack
        )
        print('Task Added')


@receiver(post_delete, sender=Tasks)
def autoDeleteSS(sender, instance, **kwargs):
    data = Tasks.objects.get(name=instance.name)
    data.delete()
    print('Task deleted')


@receiver(post_save, sender=Tasks)
def autogenerateproject(sender, instance, created, **kwargs):
    print("signal fire automatic")
    if created:
        projectdata = instance
        # print(projectdata.name)
        # print(projectdata.techstack)
        # print(projectdata.description)
        # print(projectdata.link)
        Tasks.objects.create(
            name=projectdata.name,
            description=projectdata.description,
            link=projectdata.link,
        )

        print("special skills created")


@receiver(post_delete, sender=Tasks)
def autospecialskillsgone(sender, instance, **kwargs):
    projectdata = instance
    print(projectdata.name)
    print(projectdata.description)
    print(projectdata.link)
    fdata = Tasks.objects.get(name=projectdata.name)
    fdata.delete()
