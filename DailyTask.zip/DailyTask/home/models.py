from django.db import models


# Create your models here.
class Tasks(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)
    description = models.CharField(max_length=400, null=True, blank=True)
    link = models.CharField(max_length=50)
    deadline = models.CharField(max_length=100)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.name + " " + self.deadline

    class Meta:
        verbose_name_plural = "Tasks"