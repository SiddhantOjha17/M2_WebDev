from django.http import response
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from .models import *
from .forms import NewProjForm
from django.contrib import messages

# Create your views here.

# @login_required(login_url='login')
# def home(request):
#     try:
#         data = Tasks.objects.filter(user=request.user.id)
#         context = {"proj": data}
#     except Exception as e:
#         context = {"proj": "data not found"}
#     return render(request, 'index.html', context)

@login_required(login_url='login')
def home(request):
    try:
        data = Tasks.objects.all()
        context = {"proj": data}
    except Exception as e:
        context = {"proj": "data not found"}
    return render(request, 'index.html', context)

def login_auth(request):
    if request.method == 'POST':
        username = request.POST["Text"]
        password = request.POST["Password"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            print("Wrong Credentials")
            return redirect('home')

    return render(request, 'login.html')


def NewProject(response):
    form = NewProjForm(response.POST)

    if response.method == 'POST':

        if form.is_valid():
            form.save()
            messages.success(response, "Task Added Successfully")
            # yahan pe success is the message.info

            return redirect('home')

    context = {"form": form}
    return render(response, 'newtask.html', context)

def logout_auth(request):
    logout(request)
    return redirect('home')


def signup_auth(request):
    if request.method == 'POST':
        user = request.POST['Name']
        email = request.POST['email']
        password1 = request.POST['password']
        confirmpassword = request.POST['confirmpassword']

        if password1 == confirmpassword:
            if not User.objects.filter(username=user).exists():
                if not User.objects.filter(email=email).exists():
                    user = User.objects.create_user(username=user, email=email, password=password1)
                    user.save()
                    print("New User Created")
                    login(request, user)
        return redirect('home')
    return render(request, 'register.html')

@login_required(login_url='login')
def DelProject(response, id):
    data = Tasks.objects.get(id=id)
    data.delete()

    return redirect('home')

@login_required(login_url='login')
def projectUpdate(request,id):
    myData = Tasks.objects.get(id=id)
    updateForm = NewProjForm(request.POST or None, instance=myData)
    if updateForm.is_valid():
        updateForm.save()
        messages.success(request, 'Task Updated Successfully')
        return redirect("home")
    context = {"form":updateForm}
    return render(request, 'updatetask.html',context)

