from django.urls import path
from . import views

urlpatterns =[
    path('', views.home, name ="home"),
    path('login/', views.login_auth, name = "login"),
    path('logout/', views.logout_auth, name="logout"),
    path('register/', views.signup_auth, name="register"),



    path('updateTask/<str:id>/', views.projectUpdate, name ="updatetask"),
    path('newTask/', views.NewProject, name="newtask"),
    path('deleteTask/<str:id>/', views.DelProject, name="deletetask"),

]